# Student Management System Pro

Open index.html in Chrome or Edge.