# Library Catalog Tool Pro

Features
- Add books to catalog
- Search books by title
- Delete books
- Available and issued book tracking
- Dashboard statistics
- Responsive UI

Run:
Open index.html in Chrome or Edge.
